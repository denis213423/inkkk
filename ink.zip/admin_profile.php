<!DOCTYPE html>
<html>

<head>
  <title>Админ панель</title>
</head>

<body>
  <h1>Добро пожаловать в админ панель!</h1>
  <!-- Кнопка добавления фотографии -->
  <button onclick="window.location.href = 'add_photo.php';">Добавить фотографию</button>

  <!-- Кнопка изменения фотографии -->
  <button onclick="window.location.href = 'edit_photo.php';">Изменить фотографию</button>

  <!-- Кнопка удаления фотографии -->
  <button onclick="window.location.href = 'delete_photo.php';">Удалить фотографию</button>
</body>

</html>